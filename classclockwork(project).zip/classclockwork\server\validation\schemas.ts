import { z } from 'zod';

export const DayOfWeekEnum = z.enum(['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']);

export const UnavailableSlotSchema = z.object({
  day: DayOfWeekEnum,
  period: z.number().int().min(1).max(7),
});

export const BatchSchema = z.object({
  id: z.string().min(1, 'Batch ID is required'),
  name: z.string().min(2, 'Batch name must be at least 2 characters'),
  code: z.string().min(2, 'Batch code must be at least 2 characters'),
  size: z.number().int().positive('Batch size must be a positive integer'),
  department: z.string().min(2, 'Department is required'),
});

export const FacultySchema = z.object({
  id: z.string().min(1, 'Faculty ID is required'),
  name: z.string().min(2, 'Faculty name must be at least 2 characters'),
  email: z.string().email('Valid email address is required'),
  department: z.string().min(2, 'Department is required'),
  maxWeeklyHours: z.number().int().min(1, 'Max weekly hours must be at least 1').max(40, 'Max weekly hours cannot exceed 40'),
  preferredSlot: z.enum(['ANY', 'MORNING', 'AFTERNOON']).default('ANY'),
  color: z.string().optional(),
  unavailableSlots: z.array(UnavailableSlotSchema).default([]),
});

export const ClassroomSchema = z.object({
  id: z.string().min(1, 'Classroom ID is required'),
  name: z.string().min(2, 'Classroom name must be at least 2 characters'),
  code: z.string().min(1, 'Classroom code is required'),
  capacity: z.number().int().positive('Capacity must be greater than 0'),
  type: z.enum(['LECTURE_HALL', 'LAB']),
  building: z.string().optional(),
  equipment: z.array(z.string()).default([]),
});

export const SubjectSchema = z.object({
  id: z.string().min(1, 'Subject ID is required'),
  name: z.string().min(2, 'Subject name must be at least 2 characters'),
  code: z.string().min(1, 'Subject code is required'),
  batchId: z.string().min(1, 'Associated batchId is required'),
  facultyId: z.string().min(1, 'Associated facultyId is required'),
  type: z.enum(['THEORY', 'LAB']),
  duration: z.number().int().min(1).max(3, 'Duration must be 1, 2, or 3 periods'),
  weeklyHours: z.number().int().positive('Weekly hours must be positive'),
  credits: z.number().int().min(0, 'Credits must be 0 or more'),
  requiredRoomType: z.enum(['LECTURE_HALL', 'LAB']),
  requiredEquipment: z.array(z.string()).default([]),
  color: z.string().min(1, 'Subject color is required'),
});

export const AllocationSchema = z.object({
  id: z.string().min(1, 'Allocation ID is required'),
  subjectId: z.string().min(1, 'Subject ID is required'),
  batchId: z.string().min(1, 'Batch ID is required'),
  facultyId: z.string().min(1, 'Faculty ID is required'),
  roomId: z.string().min(1, 'Room ID is required'),
  day: DayOfWeekEnum,
  period: z.number().int().min(1).max(7, 'Period must be between 1 and 7'),
  duration: z.number().int().min(1).max(3, 'Duration must be between 1 and 3'),
  isLabBlock: z.boolean().optional(),
  isLocked: z.boolean().optional(),
});

export const DatasetSchema = z.object({
  batches: z.array(BatchSchema),
  faculty: z.array(FacultySchema),
  classrooms: z.array(ClassroomSchema),
  subjects: z.array(SubjectSchema),
  allocations: z.array(AllocationSchema).default([]),
});

export const SolverConfigSchema = z.object({
  respectLunchBreak: z.boolean().default(true),
  lunchPeriod: z.number().int().min(1).max(7).default(4),
  maxConsecutiveHours: z.number().int().min(1).max(6).default(3),
  timeoutMs: z.number().int().min(500).max(30000).default(5000),
  allowSoftRelaxation: z.boolean().default(true),
  useAC3: z.boolean().default(true),
});

export const GenerateRequestSchema = z.object({
  config: SolverConfigSchema.partial().optional(),
});

export const AllocationsUpdateRequestSchema = z.object({
  allocations: z.array(AllocationSchema),
});

export const ValidateRequestSchema = z.object({
  allocations: z.array(AllocationSchema).optional(),
  lunchPeriod: z.number().int().min(0).max(7).optional(),
});

export const ICSExportRequestSchema = z.object({
  batchId: z.string().optional(),
  facultyId: z.string().optional(),
  calendarName: z.string().optional(),
});

import { describe, it, expect } from 'vitest';
import { EventEmitter } from 'events';
import { app } from '../server/index';

interface MockResponse {
  statusCode: number;
  headers: Record<string, string>;
  body: any;
}

function dispatchRequest(options: {
  method: string;
  url: string;
  body?: any;
  headers?: Record<string, string>;
}): Promise<MockResponse> {
  return new Promise((resolve) => {
    const req = Object.assign(new EventEmitter(), {
      method: options.method,
      url: options.url,
      originalUrl: options.url,
      headers: {
        'content-type': 'application/json',
        ...(options.headers || {}),
      },
      body: options.body || {},
      query: {},
      params: {},
    });

    const headers: Record<string, string> = {};
    let responseBody: any = null;

    const res = Object.assign(new EventEmitter(), {
      statusCode: 200,
      headers,
      setHeader(k: string, v: string) {
        headers[k.toLowerCase()] = v;
      },
      getHeader(k: string) {
        return headers[k.toLowerCase()];
      },
      status(code: number) {
        this.statusCode = code;
        return this;
      },
      json(data: any) {
        responseBody = data;
        this.emit('finish');
        resolve({ statusCode: this.statusCode, headers, body: responseBody });
        return this;
      },
      send(data: any) {
        responseBody = data;
        this.emit('finish');
        resolve({ statusCode: this.statusCode, headers, body: responseBody });
        return this;
      },
    });

    (app as any)(req, res);
  });
}

describe('Express REST API & Validation Middleware', () => {
  it('GET /api/health returns 200 with database status and uptime', async () => {
    const res = await dispatchRequest({ method: 'GET', url: '/api/health' });
    expect(res.statusCode).toBe(200);

    expect(res.body.status).toBe('ok');
    expect(res.body.service).toContain('ClassClockwork');
    expect(res.body.database.engine).toContain('SQLite 3');
    expect(res.body.database.journalMode).toBe('WAL');
  });

  it('GET /api/metrics returns system telemetry, memory usage, and solver statistics', async () => {
    const res = await dispatchRequest({ method: 'GET', url: '/api/metrics' });
    expect(res.statusCode).toBe(200);

    expect(res.body.status).toBe('ok');
    expect(res.body.memory.heapUsedMB).toBeGreaterThan(0);
    expect(res.body.database.tables.batches).toBeGreaterThan(0);
    expect(res.body.solver).toBeDefined();
  });

  it('GET /api/data returns full dataset from SQLite', async () => {
    const res = await dispatchRequest({ method: 'GET', url: '/api/data' });
    expect(res.statusCode).toBe(200);

    expect(res.body.batches.length).toBeGreaterThan(0);
    expect(res.body.faculty.length).toBeGreaterThan(0);
    expect(res.body.classrooms.length).toBeGreaterThan(0);
    expect(res.body.subjects.length).toBeGreaterThan(0);
  });

  it('POST /api/faculty rejects invalid email with HTTP 400 and Zod validation details', async () => {
    const invalidFaculty = {
      id: 'fac-invalid',
      name: 'Dr. Test',
      email: 'not-an-email', // INVALID EMAIL FORMAT
      department: 'Computer Science',
      maxWeeklyHours: 14,
      preferredSlot: 'ANY',
      unavailableSlots: [],
    };

    const res = await dispatchRequest({
      method: 'POST',
      url: '/api/faculty',
      body: invalidFaculty,
    });

    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(res.body.error.issues.some((i: any) => i.path === 'email')).toBe(true);
  });

  it('POST /api/classrooms rejects invalid capacity with HTTP 400', async () => {
    const invalidRoom = {
      id: 'room-invalid',
      name: 'Broken Room',
      code: 'BRK-01',
      capacity: -5, // INVALID CAPACITY (< 1)
      type: 'LECTURE_HALL',
      equipment: [],
    };

    const res = await dispatchRequest({
      method: 'POST',
      url: '/api/classrooms',
      body: invalidRoom,
    });

    expect(res.statusCode).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('VALIDATION_ERROR');
    expect(res.body.error.issues.some((i: any) => i.path === 'capacity')).toBe(true);
  });

  it('POST /api/generate solves CSP, saves allocations to SQLite, and returns AC-3 metrics', async () => {
    const res = await dispatchRequest({
      method: 'POST',
      url: '/api/generate',
      body: {
        config: {
          respectLunchBreak: true,
          lunchPeriod: 4,
          useAC3: true,
        },
      },
    });

    expect(res.statusCode).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.allocations.length).toBeGreaterThan(35);
    expect(res.body.executionTimeMs).toBeGreaterThan(0);
    expect(res.body.ac3Stats).toBeDefined();
  });

  it('POST /api/export/ics returns valid iCalendar RFC 5545 format', async () => {
    const res = await dispatchRequest({
      method: 'POST',
      url: '/api/export/ics',
      body: {
        calendarName: 'Computer Science Semester Timetable',
      },
    });

    expect(res.statusCode).toBe(200);
    expect(res.headers['content-type']).toContain('text/calendar');

    expect(res.body).toContain('BEGIN:VCALENDAR');
    expect(res.body).toContain('VERSION:2.0');
    expect(res.body).toContain('PRODID:-//ClassClockwork//ZeroClash');
    expect(res.body).toContain('END:VCALENDAR');
  });
});

import { describe, it, expect } from 'vitest';
import { auditTimetable } from '../src/validator';
import { INITIAL_DATASET } from '../src/sampleData';
import { TimetableAllocation } from '../src/types';

describe('Real-Time Conflict Auditor (auditTimetable)', () => {
  it('detects faculty double-booking clash instantly', () => {
    const drSharma = INITIAL_DATASET.faculty[0];
    const room1 = INITIAL_DATASET.classrooms[0];
    const room2 = INITIAL_DATASET.classrooms[1];

    const conflictingAllocations: TimetableAllocation[] = [
      {
        id: 'alloc-1',
        subjectId: INITIAL_DATASET.subjects[0].id,
        batchId: 'batch-cs4a',
        facultyId: drSharma.id,
        roomId: room1.id,
        day: 'Monday',
        period: 2,
        duration: 1,
      },
      {
        id: 'alloc-2',
        subjectId: INITIAL_DATASET.subjects[1].id,
        batchId: 'batch-cs4b',
        facultyId: drSharma.id, // SAME FACULTY in two different rooms at same time!
        roomId: room2.id,
        day: 'Monday',
        period: 2,
        duration: 1,
      },
    ];

    const clashes = auditTimetable({
      batches: INITIAL_DATASET.batches,
      faculty: INITIAL_DATASET.faculty,
      classrooms: INITIAL_DATASET.classrooms,
      subjects: INITIAL_DATASET.subjects,
      allocations: conflictingAllocations,
      lunchPeriod: 4,
    });

    const facultyClash = clashes.find((c) => c.type === 'FACULTY_DOUBLE_BOOKED');
    expect(facultyClash).toBeDefined();
    expect(facultyClash?.severity).toBe('CRITICAL');
    expect(facultyClash?.message).toContain(drSharma.name);
  });

  it('detects room double-booking clash instantly', () => {
    const room1 = INITIAL_DATASET.classrooms[0];

    const conflictingAllocations: TimetableAllocation[] = [
      {
        id: 'alloc-1',
        subjectId: INITIAL_DATASET.subjects[0].id,
        batchId: 'batch-cs4a',
        facultyId: INITIAL_DATASET.faculty[0].id,
        roomId: room1.id, // SAME ROOM
        day: 'Wednesday',
        period: 3,
        duration: 1,
      },
      {
        id: 'alloc-2',
        subjectId: INITIAL_DATASET.subjects[2].id,
        batchId: 'batch-cs6',
        facultyId: INITIAL_DATASET.faculty[1].id,
        roomId: room1.id, // SAME ROOM at same time!
        day: 'Wednesday',
        period: 3,
        duration: 1,
      },
    ];

    const clashes = auditTimetable({
      batches: INITIAL_DATASET.batches,
      faculty: INITIAL_DATASET.faculty,
      classrooms: INITIAL_DATASET.classrooms,
      subjects: INITIAL_DATASET.subjects,
      allocations: conflictingAllocations,
    });

    const roomClash = clashes.find((c) => c.type === 'ROOM_DOUBLE_BOOKED');
    expect(roomClash).toBeDefined();
    expect(roomClash?.severity).toBe('CRITICAL');
  });

  it('detects classroom capacity exceeded', () => {
    const smallRoom = {
      ...INITIAL_DATASET.classrooms[0],
      id: 'tiny-room',
      name: 'Tiny Seminar Room',
      capacity: 25, // Small capacity!
    };
    const largeBatch = INITIAL_DATASET.batches.find((b) => b.size > 25)!;

    const allocations: TimetableAllocation[] = [
      {
        id: 'alloc-overcap',
        subjectId: INITIAL_DATASET.subjects[0].id,
        batchId: largeBatch.id,
        facultyId: INITIAL_DATASET.faculty[0].id,
        roomId: smallRoom.id,
        day: 'Tuesday',
        period: 1,
        duration: 1,
      },
    ];

    const clashes = auditTimetable({
      batches: INITIAL_DATASET.batches,
      faculty: INITIAL_DATASET.faculty,
      classrooms: [...INITIAL_DATASET.classrooms, smallRoom],
      subjects: INITIAL_DATASET.subjects,
      allocations,
    });

    const capClash = clashes.find((c) => c.type === 'CAPACITY_EXCEEDED');
    expect(capClash).toBeDefined();
    expect(capClash?.severity).toBe('CRITICAL');
  });

  it('detects lab equipment mismatch when assigned to non-lab room', () => {
    const labSubject = INITIAL_DATASET.subjects.find((s) => s.type === 'LAB')!;
    const standardRoom = INITIAL_DATASET.classrooms.find((r) => r.type === 'LECTURE_HALL')!;

    const allocations: TimetableAllocation[] = [
      {
        id: 'alloc-lab-mismatch',
        subjectId: labSubject.id,
        batchId: labSubject.batchId,
        facultyId: labSubject.facultyId,
        roomId: standardRoom.id, // Standard lecture hall for a lab course
        day: 'Thursday',
        period: 5,
        duration: 2,
      },
    ];

    const clashes = auditTimetable({
      batches: INITIAL_DATASET.batches,
      faculty: INITIAL_DATASET.faculty,
      classrooms: INITIAL_DATASET.classrooms,
      subjects: INITIAL_DATASET.subjects,
      allocations,
    });

    const equipClash = clashes.find((c) => c.type === 'LAB_EQUIPMENT_MISMATCH');
    expect(equipClash).toBeDefined();
    expect(equipClash?.severity).toBe('CRITICAL');
  });

  it('detects scheduling during faculty declared unavailable slot', () => {
    const facWithUnavail = INITIAL_DATASET.faculty.find((f) => f.unavailableSlots.length > 0)!;
    const unavailSlot = facWithUnavail.unavailableSlots[0];

    const allocations: TimetableAllocation[] = [
      {
        id: 'alloc-unavail-test',
        subjectId: INITIAL_DATASET.subjects[0].id,
        batchId: INITIAL_DATASET.batches[0].id,
        facultyId: facWithUnavail.id,
        roomId: INITIAL_DATASET.classrooms[0].id,
        day: unavailSlot.day,
        period: unavailSlot.period,
        duration: 1,
      },
    ];

    const clashes = auditTimetable({
      batches: INITIAL_DATASET.batches,
      faculty: INITIAL_DATASET.faculty,
      classrooms: INITIAL_DATASET.classrooms,
      subjects: INITIAL_DATASET.subjects,
      allocations,
    });

    const unavailClash = clashes.find((c) => c.type === 'FACULTY_UNAVAILABLE');
    expect(unavailClash).toBeDefined();
    expect(unavailClash?.severity).toBe('CRITICAL');
  });
});

import { Request, Response, NextFunction } from 'express';
import { randomUUID } from 'crypto';
import { logger } from '../utils/logger';

declare global {
  namespace Express {
    interface Request {
      id?: string;
      startTime?: number;
    }
  }
}

export function requestLogger(req: Request, res: Response, next: NextFunction) {
  const reqId = (req.headers['x-request-id'] as string) || randomUUID();
  req.id = reqId;
  req.startTime = Date.now();

  res.setHeader('X-Request-Id', reqId);

  // Log incoming request
  logger.info(`--> ${req.method} ${req.originalUrl}`, undefined, reqId);

  res.on('finish', () => {
    const elapsed = Date.now() - (req.startTime || Date.now());
    res.setHeader('X-Response-Time', `${elapsed}ms`);

    const message = `<-- ${req.method} ${req.originalUrl} ${res.statusCode} (${elapsed}ms)`;
    if (res.statusCode >= 500) {
      logger.error(message, undefined, reqId);
    } else if (res.statusCode >= 400) {
      logger.warn(message, undefined, reqId);
    } else {
      logger.info(message, undefined, reqId);
    }
  });

  next();
}

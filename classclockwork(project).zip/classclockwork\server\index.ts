import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { INITIAL_DATASET } from '../src/sampleData';
import { TimetableDataset } from '../src/types';
import { TimetableCSPSolver } from '../src/solver';
import { auditTimetable } from '../src/validator';
import { generateICS } from '../src/icsExporter';
import { TimetableDatabase } from './db/database';
import { logger } from './utils/logger';
import { requestLogger } from './middleware/requestLogger';
import { errorHandler } from './middleware/errorHandler';
import { validateBody } from './middleware/validate';
import {
  BatchSchema,
  ClassroomSchema,
  FacultySchema,
  SubjectSchema,
  DatasetSchema,
  GenerateRequestSchema,
  AllocationsUpdateRequestSchema,
  ValidateRequestSchema,
  ICSExportRequestSchema,
} from './validation/schemas';
import { ApiError } from './utils/apiError';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const app = express();
const PORT = process.env.PORT || 3001;

// Initialize SQLite Relational Database Engine (WAL mode, Foreign Keys)
export const database = new TimetableDatabase();

app.use(cors());
app.use(express.json({ limit: '5mb' }));
app.use(requestLogger);

// 1. Deep Health Check Endpoint
app.get('/api/health', (req, res) => {
  try {
    const stats = database.getDatabaseStats();
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
      service: 'ClassClockwork ZeroClash API',
      version: '2.0.0',
      database: {
        status: 'connected',
        engine: stats.engine,
        journalMode: stats.journalMode,
      },
      uptime: process.uptime(),
    });
  } catch (err: any) {
    throw ApiError.internal(`Healthcheck failed: ${err.message}`);
  }
});

// 2. System Observability & Telemetry Metrics Endpoint
app.get('/api/metrics', (req, res) => {
  const mem = process.memoryUsage();
  const dbStats = database.getDatabaseStats();
  const history = database.getSolverMetricsHistory(15);

  const totalSolves = history.length;
  const avgExecutionTimeMs =
    totalSolves > 0
      ? Math.round(history.reduce((sum, h) => sum + Number(h.execution_time_ms), 0) / totalSolves)
      : 0;

  const lastGini = totalSolves > 0 ? Number(history[0].gini_coefficient) : 0;

  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.round(process.uptime()),
    memory: {
      heapUsedMB: Math.round((mem.heapUsed / 1024 / 1024) * 100) / 100,
      heapTotalMB: Math.round((mem.heapTotal / 1024 / 1024) * 100) / 100,
      rssMB: Math.round((mem.rss / 1024 / 1024) * 100) / 100,
    },
    database: dbStats,
    solver: {
      totalSolves,
      avgExecutionTimeMs,
      lastGiniCoefficient: lastGini,
      history: history.map((h) => ({
        id: h.id,
        executionTimeMs: h.execution_time_ms,
        iterations: h.total_iterations,
        domainsPruned: h.domains_pruned || 0,
        gini: h.gini_coefficient,
        clashes: h.clashes_count,
        success: Boolean(h.success),
        timestamp: h.created_at,
      })),
    },
    recentLogs: logger.getRecentLogs(20),
  });
});

// 3. Get entire dataset (from SQLite relational store)
app.get('/api/data', (req, res) => {
  const data = database.getDataset();
  res.json(data);
});

// 4. Reset dataset to benchmark computer science semester scenario
app.post('/api/data/reset', (req, res) => {
  database.saveDataset(INITIAL_DATASET);
  const resetData = database.getDataset();
  logger.info('Database successfully reset to Computer Science Benchmark Scenario', undefined, req.id);
  res.json({
    success: true,
    message: 'Dataset successfully reset to CS Benchmark Scenario (SQLite populated)',
    dataset: resetData,
  });
});

// 5. Save entire dataset with strict Zod validation
app.post('/api/data', validateBody(DatasetSchema), (req, res) => {
  const dataset: TimetableDataset = req.body;
  database.saveDataset(dataset);
  logger.info(`Dataset replaced: ${dataset.subjects.length} subjects, ${dataset.allocations.length} allocations`, undefined, req.id);
  res.json({
    success: true,
    message: 'Dataset updated successfully in SQLite relational store',
    dataset,
  });
});

// 6. CSP Solver Endpoint (Core Feature with AC-3, MRV, and Telemetry)
app.post('/api/generate', validateBody(GenerateRequestSchema), (req, res) => {
  const config = req.body.config || {};
  const dataset = database.getDataset();

  const solver = new TimetableCSPSolver(
    dataset.batches,
    dataset.faculty,
    dataset.classrooms,
    dataset.subjects,
    config
  );

  const result = solver.solve();

  // Save new allocations atomically to SQLite
  database.saveAllocations(result.allocations);

  // Record solver performance metrics in SQLite history table
  database.recordSolverMetric({
    executionTimeMs: result.executionTimeMs,
    totalIterations: result.totalIterations,
    domainsPruned: result.ac3Stats?.domainsPruned || 0,
    giniCoefficient: result.giniCoefficient,
    clashesCount: result.clashes.length,
    success: result.success,
  });

  logger.info(
    `CSP Solved: ${result.allocations.length} slots in ${result.executionTimeMs}ms (${result.totalIterations} iters, ${result.ac3Stats?.domainsPruned || 0} AC-3 pruned, Gini: ${result.giniCoefficient})`,
    undefined,
    req.id
  );

  res.json({
    ...result,
    dataset: database.getDataset(),
  });
});

// 7. Real-time Clash Auditor Endpoint with strict validation
app.post('/api/validate', validateBody(ValidateRequestSchema), (req, res) => {
  const dataset = database.getDataset();
  const allocations = req.body.allocations || dataset.allocations;
  const lunchPeriod = req.body.lunchPeriod ?? 4;

  const clashes = auditTimetable({
    batches: dataset.batches,
    faculty: dataset.faculty,
    classrooms: dataset.classrooms,
    subjects: dataset.subjects,
    allocations,
    lunchPeriod,
  });

  res.json({
    totalClashes: clashes.length,
    criticalClashes: clashes.filter((c) => c.severity === 'CRITICAL').length,
    warnings: clashes.filter((c) => c.severity === 'WARNING').length,
    clashes,
  });
});

// 8. Update Allocations (e.g. after manual drag-and-drop) with Zod validation
app.post('/api/allocations', validateBody(AllocationsUpdateRequestSchema), (req, res) => {
  const { allocations } = req.body;
  database.saveAllocations(allocations);
  logger.info(`Updated allocations: ${allocations.length} active assignments`, undefined, req.id);
  res.json({
    success: true,
    message: 'Allocations updated in SQLite database',
    count: allocations.length,
  });
});

// 9. iCalendar .ics export endpoint with Zod validation
app.post('/api/export/ics', validateBody(ICSExportRequestSchema), (req, res) => {
  const { batchId, facultyId, calendarName } = req.body;
  const dataset = database.getDataset();

  const icsString = generateICS({
    allocations: dataset.allocations,
    subjects: dataset.subjects,
    faculty: dataset.faculty,
    classrooms: dataset.classrooms,
    batches: dataset.batches,
    filterBatchId: batchId,
    filterFacultyId: facultyId,
    calendarName,
  });

  res.setHeader('Content-Type', 'text/calendar; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename="classclockwork-timetable.ics"');
  res.send(icsString);
});

// 10. Resource Intake Endpoints with strict Zod validation
app.post('/api/faculty', validateBody(FacultySchema), (req, res) => {
  database.upsertFaculty(req.body);
  const updatedDataset = database.getDataset();
  logger.info(`Upserted faculty member: ${req.body.name}`, undefined, req.id);
  res.json({ success: true, faculty: updatedDataset.faculty });
});

app.delete('/api/faculty/:id', (req, res) => {
  database.deleteFaculty(req.params.id);
  const updatedDataset = database.getDataset();
  logger.info(`Deleted faculty member: ${req.params.id}`, undefined, req.id);
  res.json({ success: true, faculty: updatedDataset.faculty });
});

app.post('/api/subjects', validateBody(SubjectSchema), (req, res) => {
  database.upsertSubject(req.body);
  const updatedDataset = database.getDataset();
  logger.info(`Upserted subject: ${req.body.name} (${req.body.code})`, undefined, req.id);
  res.json({ success: true, subjects: updatedDataset.subjects });
});

app.delete('/api/subjects/:id', (req, res) => {
  database.deleteSubject(req.params.id);
  const updatedDataset = database.getDataset();
  logger.info(`Deleted subject: ${req.params.id}`, undefined, req.id);
  res.json({ success: true, subjects: updatedDataset.subjects });
});

app.post('/api/classrooms', validateBody(ClassroomSchema), (req, res) => {
  database.upsertClassroom(req.body);
  const updatedDataset = database.getDataset();
  logger.info(`Upserted classroom: ${req.body.name} (${req.body.code})`, undefined, req.id);
  res.json({ success: true, classrooms: updatedDataset.classrooms });
});

app.delete('/api/classrooms/:id', (req, res) => {
  database.deleteClassroom(req.params.id);
  const updatedDataset = database.getDataset();
  logger.info(`Deleted classroom: ${req.params.id}`, undefined, req.id);
  res.json({ success: true, classrooms: updatedDataset.classrooms });
});

app.post('/api/batches', validateBody(BatchSchema), (req, res) => {
  database.upsertBatch(req.body);
  const updatedDataset = database.getDataset();
  logger.info(`Upserted batch: ${req.body.name} (${req.body.code})`, undefined, req.id);
  res.json({ success: true, batches: updatedDataset.batches });
});

app.delete('/api/batches/:id', (req, res) => {
  database.deleteBatch(req.params.id);
  const updatedDataset = database.getDataset();
  logger.info(`Deleted batch: ${req.params.id}`, undefined, req.id);
  res.json({ success: true, batches: updatedDataset.batches });
});

// Serve static client assets if built
const distPath = path.join(__dirname, '..', 'dist');
if (process.env.NODE_ENV === 'production' || process.env.SERVE_STATIC === 'true') {
  app.use(express.static(distPath));
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

// Global Centralized Error Handling Middleware
app.use(errorHandler);

// Only listen when executed directly (not when imported in tests)
if (process.env.NODE_ENV !== 'test') {
  app.listen(PORT, () => {
    logger.info(`ClassClockwork ZeroClash API running on http://localhost:${PORT}`);
    logger.info(`Database: SQLite 3 with WAL Mode enabled at server/data/classclockwork.db`);
  });
}

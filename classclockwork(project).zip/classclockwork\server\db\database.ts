import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import {
  Batch,
  Classroom,
  Faculty,
  Subject,
  TimetableAllocation,
  TimetableDataset,
} from '../../src/types';
import { INITIAL_DATASET } from '../../src/sampleData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface DatabaseStats {
  engine: string;
  journalMode: string;
  path: string;
  fileSizeBytes: number;
  tables: {
    batches: number;
    faculty: number;
    classrooms: number;
    subjects: number;
    allocations: number;
  };
}

export class TimetableDatabase {
  private db: DatabaseSync;
  private dbPath: string;

  constructor(customPath?: string) {
    if (customPath) {
      this.dbPath = customPath;
    } else {
      const dataDir = path.join(__dirname, '..', 'data');
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      this.dbPath = path.join(dataDir, 'classclockwork.db');
    }

    this.db = new DatabaseSync(this.dbPath);
    this.configurePragmas();
    this.initializeSchema();
    this.seedIfEmpty();
  }

  private configurePragmas(): void {
    // Enable WAL (Write-Ahead Logging) for high concurrency
    this.db.exec('PRAGMA journal_mode = WAL;');
    // Enable foreign keys constraint enforcement
    this.db.exec('PRAGMA foreign_keys = ON;');
    this.db.exec('PRAGMA synchronous = NORMAL;');
    this.db.exec('PRAGMA busy_timeout = 5000;');
  }

  private initializeSchema(): void {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS batches (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        size INTEGER NOT NULL,
        department TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS faculty (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        department TEXT NOT NULL,
        max_weekly_hours INTEGER NOT NULL,
        preferred_slot TEXT NOT NULL,
        color TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS faculty_unavailable_slots (
        id TEXT PRIMARY KEY,
        faculty_id TEXT NOT NULL REFERENCES faculty(id) ON DELETE CASCADE,
        day TEXT NOT NULL,
        period INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS classrooms (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        capacity INTEGER NOT NULL,
        type TEXT NOT NULL,
        building TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS classroom_equipment (
        classroom_id TEXT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE,
        equipment TEXT NOT NULL,
        PRIMARY KEY (classroom_id, equipment)
      );

      CREATE TABLE IF NOT EXISTS subjects (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        code TEXT NOT NULL,
        batch_id TEXT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
        faculty_id TEXT NOT NULL REFERENCES faculty(id) ON DELETE CASCADE,
        type TEXT NOT NULL,
        duration INTEGER NOT NULL,
        weekly_hours INTEGER NOT NULL,
        credits INTEGER NOT NULL,
        required_room_type TEXT NOT NULL,
        color TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS subject_equipment (
        subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        equipment TEXT NOT NULL,
        PRIMARY KEY (subject_id, equipment)
      );

      CREATE TABLE IF NOT EXISTS allocations (
        id TEXT PRIMARY KEY,
        subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
        batch_id TEXT NOT NULL REFERENCES batches(id) ON DELETE CASCADE,
        faculty_id TEXT NOT NULL REFERENCES faculty(id) ON DELETE CASCADE,
        room_id TEXT NOT NULL REFERENCES classrooms(id) ON DELETE CASCADE,
        day TEXT NOT NULL,
        period INTEGER NOT NULL,
        duration INTEGER NOT NULL,
        is_lab_block INTEGER NOT NULL,
        is_locked INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS solver_metrics_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        execution_time_ms INTEGER NOT NULL,
        total_iterations INTEGER NOT NULL,
        domains_pruned INTEGER,
        gini_coefficient REAL,
        clashes_count INTEGER,
        success INTEGER NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_allocations_slot ON allocations(day, period);
      CREATE INDEX IF NOT EXISTS idx_allocations_faculty ON allocations(faculty_id);
      CREATE INDEX IF NOT EXISTS idx_allocations_batch ON allocations(batch_id);
      CREATE INDEX IF NOT EXISTS idx_allocations_room ON allocations(room_id);
      CREATE INDEX IF NOT EXISTS idx_subjects_batch ON subjects(batch_id);
      CREATE INDEX IF NOT EXISTS idx_subjects_faculty ON subjects(faculty_id);
    `);
  }

  private seedIfEmpty(): void {
    const row = this.db.prepare('SELECT COUNT(*) as count FROM batches').get() as { count: number };
    if (row && row.count === 0) {
      this.saveDataset(INITIAL_DATASET);
    }
  }

  public getDataset(): TimetableDataset {
    // 1. Fetch batches
    const batches = (this.db.prepare('SELECT id, name, code, size, department FROM batches ORDER BY name').all() as any[]).map(
      (b) => ({
        id: b.id,
        name: b.name,
        code: b.code,
        size: Number(b.size),
        department: b.department,
      })
    );

    // 2. Fetch faculty with unavailable slots
    const facultyRows = this.db.prepare('SELECT id, name, email, department, max_weekly_hours, preferred_slot, color FROM faculty ORDER BY name').all() as any[];
    const unavailableRows = this.db.prepare('SELECT id, faculty_id, day, period FROM faculty_unavailable_slots').all() as any[];

    const unavailMap = new Map<string, { day: any; period: number }[]>();
    for (const u of unavailableRows) {
      if (!unavailMap.has(u.faculty_id)) {
        unavailMap.set(u.faculty_id, []);
      }
      unavailMap.get(u.faculty_id)!.push({ day: u.day, period: Number(u.period) });
    }

    const faculty: Faculty[] = facultyRows.map((f) => ({
      id: f.id,
      name: f.name,
      email: f.email,
      department: f.department,
      maxWeeklyHours: Number(f.max_weekly_hours),
      preferredSlot: f.preferred_slot,
      color: f.color || undefined,
      unavailableSlots: unavailMap.get(f.id) || [],
    }));

    // 3. Fetch classrooms with equipment
    const roomRows = this.db.prepare('SELECT id, name, code, capacity, type, building FROM classrooms ORDER BY code').all() as any[];
    const roomEquipRows = this.db.prepare('SELECT classroom_id, equipment FROM classroom_equipment').all() as any[];

    const roomEquipMap = new Map<string, string[]>();
    for (const re of roomEquipRows) {
      if (!roomEquipMap.has(re.classroom_id)) {
        roomEquipMap.set(re.classroom_id, []);
      }
      roomEquipMap.get(re.classroom_id)!.push(re.equipment);
    }

    const classrooms: Classroom[] = roomRows.map((r) => ({
      id: r.id,
      name: r.name,
      code: r.code,
      capacity: Number(r.capacity),
      type: r.type,
      building: r.building || undefined,
      equipment: roomEquipMap.get(r.id) || [],
    }));

    // 4. Fetch subjects with required equipment
    const subjectRows = this.db.prepare('SELECT id, name, code, batch_id, faculty_id, type, duration, weekly_hours, credits, required_room_type, color FROM subjects ORDER BY code').all() as any[];
    const subEquipRows = this.db.prepare('SELECT subject_id, equipment FROM subject_equipment').all() as any[];

    const subEquipMap = new Map<string, string[]>();
    for (const se of subEquipRows) {
      if (!subEquipMap.has(se.subject_id)) {
        subEquipMap.set(se.subject_id, []);
      }
      subEquipMap.get(se.subject_id)!.push(se.equipment);
    }

    const subjects: Subject[] = subjectRows.map((s) => ({
      id: s.id,
      name: s.name,
      code: s.code,
      batchId: s.batch_id,
      facultyId: s.faculty_id,
      type: s.type,
      duration: Number(s.duration),
      weeklyHours: Number(s.weekly_hours),
      credits: Number(s.credits),
      requiredRoomType: s.required_room_type,
      color: s.color,
      requiredEquipment: subEquipMap.get(s.id) || [],
    }));

    // 5. Fetch allocations
    const allocRows = this.db.prepare('SELECT id, subject_id, batch_id, faculty_id, room_id, day, period, duration, is_lab_block, is_locked FROM allocations').all() as any[];
    const allocations: TimetableAllocation[] = allocRows.map((a) => ({
      id: a.id,
      subjectId: a.subject_id,
      batchId: a.batch_id,
      facultyId: a.faculty_id,
      roomId: a.room_id,
      day: a.day,
      period: Number(a.period),
      duration: Number(a.duration),
      isLabBlock: Boolean(a.is_lab_block),
      isLocked: Boolean(a.is_locked),
    }));

    return {
      batches,
      faculty,
      classrooms,
      subjects,
      allocations,
    };
  }

  public saveDataset(dataset: TimetableDataset): void {
    const now = new Date().toISOString();

    // Use a single atomic transaction for full dataset persistence
    this.db.exec('BEGIN TRANSACTION;');
    try {
      // Clear tables in foreign-key safe order
      this.db.exec('DELETE FROM allocations;');
      this.db.exec('DELETE FROM subject_equipment;');
      this.db.exec('DELETE FROM subjects;');
      this.db.exec('DELETE FROM classroom_equipment;');
      this.db.exec('DELETE FROM classrooms;');
      this.db.exec('DELETE FROM faculty_unavailable_slots;');
      this.db.exec('DELETE FROM faculty;');
      this.db.exec('DELETE FROM batches;');

      // Insert Batches
      const insertBatch = this.db.prepare(
        'INSERT INTO batches (id, name, code, size, department, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
      );
      for (const b of dataset.batches) {
        insertBatch.run(b.id, b.name, b.code, b.size, b.department, now, now);
      }

      // Insert Faculty
      const insertFaculty = this.db.prepare(
        'INSERT INTO faculty (id, name, email, department, max_weekly_hours, preferred_slot, color, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      const insertUnavail = this.db.prepare(
        'INSERT INTO faculty_unavailable_slots (id, faculty_id, day, period) VALUES (?, ?, ?, ?)'
      );
      for (const f of dataset.faculty) {
        insertFaculty.run(f.id, f.name, f.email, f.department, f.maxWeeklyHours, f.preferredSlot, f.color || null, now, now);
        if (f.unavailableSlots) {
          for (const u of f.unavailableSlots) {
            insertUnavail.run(`unavail-${f.id}-${u.day}-${u.period}`, f.id, u.day, u.period);
          }
        }
      }

      // Insert Classrooms
      const insertRoom = this.db.prepare(
        'INSERT INTO classrooms (id, name, code, capacity, type, building, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
      );
      const insertRoomEquip = this.db.prepare(
        'INSERT INTO classroom_equipment (classroom_id, equipment) VALUES (?, ?)'
      );
      for (const r of dataset.classrooms) {
        insertRoom.run(r.id, r.name, r.code, r.capacity, r.type, r.building || null, now, now);
        if (r.equipment) {
          for (const eq of r.equipment) {
            insertRoomEquip.run(r.id, eq);
          }
        }
      }

      // Insert Subjects
      const insertSubject = this.db.prepare(
        'INSERT INTO subjects (id, name, code, batch_id, faculty_id, type, duration, weekly_hours, credits, required_room_type, color, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      const insertSubEquip = this.db.prepare(
        'INSERT INTO subject_equipment (subject_id, equipment) VALUES (?, ?)'
      );
      for (const s of dataset.subjects) {
        insertSubject.run(
          s.id,
          s.name,
          s.code,
          s.batchId,
          s.facultyId,
          s.type,
          s.duration,
          s.weeklyHours,
          s.credits,
          s.requiredRoomType,
          s.color,
          now,
          now
        );
        if (s.requiredEquipment) {
          for (const eq of s.requiredEquipment) {
            insertSubEquip.run(s.id, eq);
          }
        }
      }

      // Insert Allocations
      if (dataset.allocations && dataset.allocations.length > 0) {
        const insertAlloc = this.db.prepare(
          'INSERT INTO allocations (id, subject_id, batch_id, faculty_id, room_id, day, period, duration, is_lab_block, is_locked, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        for (const a of dataset.allocations) {
          insertAlloc.run(
            a.id,
            a.subjectId,
            a.batchId,
            a.facultyId,
            a.roomId,
            a.day,
            a.period,
            a.duration,
            a.isLabBlock ? 1 : 0,
            a.isLocked ? 1 : 0,
            now,
            now
          );
        }
      }

      this.db.exec('COMMIT;');
    } catch (err) {
      this.db.exec('ROLLBACK;');
      throw err;
    }
  }

  public saveAllocations(allocations: TimetableAllocation[]): void {
    const now = new Date().toISOString();
    this.db.exec('BEGIN TRANSACTION;');
    try {
      this.db.exec('DELETE FROM allocations;');
      const insertAlloc = this.db.prepare(
        'INSERT INTO allocations (id, subject_id, batch_id, faculty_id, room_id, day, period, duration, is_lab_block, is_locked, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      for (const a of allocations) {
        insertAlloc.run(
          a.id,
          a.subjectId,
          a.batchId,
          a.facultyId,
          a.roomId,
          a.day,
          a.period,
          a.duration,
          a.isLabBlock ? 1 : 0,
          a.isLocked ? 1 : 0,
          now,
          now
        );
      }
      this.db.exec('COMMIT;');
    } catch (err) {
      this.db.exec('ROLLBACK;');
      throw err;
    }
  }

  public upsertBatch(batch: Batch): void {
    const now = new Date().toISOString();
    const existing = this.db.prepare('SELECT id FROM batches WHERE id = ?').get(batch.id);
    if (existing) {
      this.db
        .prepare('UPDATE batches SET name = ?, code = ?, size = ?, department = ?, updated_at = ? WHERE id = ?')
        .run(batch.name, batch.code, batch.size, batch.department, now, batch.id);
    } else {
      this.db
        .prepare('INSERT INTO batches (id, name, code, size, department, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
        .run(batch.id, batch.name, batch.code, batch.size, batch.department, now, now);
    }
  }

  public deleteBatch(id: string): void {
    this.db.prepare('DELETE FROM batches WHERE id = ?').run(id);
  }

  public upsertFaculty(f: Faculty): void {
    const now = new Date().toISOString();
    this.db.exec('BEGIN TRANSACTION;');
    try {
      const existing = this.db.prepare('SELECT id FROM faculty WHERE id = ?').get(f.id);
      if (existing) {
        this.db
          .prepare(
            'UPDATE faculty SET name = ?, email = ?, department = ?, max_weekly_hours = ?, preferred_slot = ?, color = ?, updated_at = ? WHERE id = ?'
          )
          .run(f.name, f.email, f.department, f.maxWeeklyHours, f.preferredSlot, f.color || null, now, f.id);
      } else {
        this.db
          .prepare(
            'INSERT INTO faculty (id, name, email, department, max_weekly_hours, preferred_slot, color, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
          )
          .run(f.id, f.name, f.email, f.department, f.maxWeeklyHours, f.preferredSlot, f.color || null, now, now);
      }

      // Re-insert unavailable slots
      this.db.prepare('DELETE FROM faculty_unavailable_slots WHERE faculty_id = ?').run(f.id);
      if (f.unavailableSlots && f.unavailableSlots.length > 0) {
        const insertUnavail = this.db.prepare(
          'INSERT INTO faculty_unavailable_slots (id, faculty_id, day, period) VALUES (?, ?, ?, ?)'
        );
        for (const u of f.unavailableSlots) {
          insertUnavail.run(`unavail-${f.id}-${u.day}-${u.period}`, f.id, u.day, u.period);
        }
      }
      this.db.exec('COMMIT;');
    } catch (err) {
      this.db.exec('ROLLBACK;');
      throw err;
    }
  }

  public deleteFaculty(id: string): void {
    this.db.prepare('DELETE FROM faculty WHERE id = ?').run(id);
  }

  public upsertClassroom(r: Classroom): void {
    const now = new Date().toISOString();
    this.db.exec('BEGIN TRANSACTION;');
    try {
      const existing = this.db.prepare('SELECT id FROM classrooms WHERE id = ?').get(r.id);
      if (existing) {
        this.db
          .prepare('UPDATE classrooms SET name = ?, code = ?, capacity = ?, type = ?, building = ?, updated_at = ? WHERE id = ?')
          .run(r.name, r.code, r.capacity, r.type, r.building || null, now, r.id);
      } else {
        this.db
          .prepare('INSERT INTO classrooms (id, name, code, capacity, type, building, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
          .run(r.id, r.name, r.code, r.capacity, r.type, r.building || null, now, now);
      }

      this.db.prepare('DELETE FROM classroom_equipment WHERE classroom_id = ?').run(r.id);
      if (r.equipment && r.equipment.length > 0) {
        const insertEquip = this.db.prepare('INSERT INTO classroom_equipment (classroom_id, equipment) VALUES (?, ?)');
        for (const eq of r.equipment) {
          insertEquip.run(r.id, eq);
        }
      }
      this.db.exec('COMMIT;');
    } catch (err) {
      this.db.exec('ROLLBACK;');
      throw err;
    }
  }

  public deleteClassroom(id: string): void {
    this.db.prepare('DELETE FROM classrooms WHERE id = ?').run(id);
  }

  public upsertSubject(s: Subject): void {
    const now = new Date().toISOString();
    this.db.exec('BEGIN TRANSACTION;');
    try {
      const existing = this.db.prepare('SELECT id FROM subjects WHERE id = ?').get(s.id);
      if (existing) {
        this.db
          .prepare(
            'UPDATE subjects SET name = ?, code = ?, batch_id = ?, faculty_id = ?, type = ?, duration = ?, weekly_hours = ?, credits = ?, required_room_type = ?, color = ?, updated_at = ? WHERE id = ?'
          )
          .run(
            s.name,
            s.code,
            s.batchId,
            s.facultyId,
            s.type,
            s.duration,
            s.weeklyHours,
            s.credits,
            s.requiredRoomType,
            s.color,
            now,
            s.id
          );
      } else {
        this.db
          .prepare(
            'INSERT INTO subjects (id, name, code, batch_id, faculty_id, type, duration, weekly_hours, credits, required_room_type, color, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
          )
          .run(
            s.id,
            s.name,
            s.code,
            s.batchId,
            s.facultyId,
            s.type,
            s.duration,
            s.weeklyHours,
            s.credits,
            s.requiredRoomType,
            s.color,
            now,
            now
          );
      }

      this.db.prepare('DELETE FROM subject_equipment WHERE subject_id = ?').run(s.id);
      if (s.requiredEquipment && s.requiredEquipment.length > 0) {
        const insertEquip = this.db.prepare('INSERT INTO subject_equipment (subject_id, equipment) VALUES (?, ?)');
        for (const eq of s.requiredEquipment) {
          insertEquip.run(s.id, eq);
        }
      }
      this.db.exec('COMMIT;');
    } catch (err) {
      this.db.exec('ROLLBACK;');
      throw err;
    }
  }

  public deleteSubject(id: string): void {
    this.db.prepare('DELETE FROM subjects WHERE id = ?').run(id);
  }

  public recordSolverMetric(data: {
    executionTimeMs: number;
    totalIterations: number;
    domainsPruned: number;
    giniCoefficient: number;
    clashesCount: number;
    success: boolean;
  }): void {
    const now = new Date().toISOString();
    this.db
      .prepare(
        'INSERT INTO solver_metrics_history (execution_time_ms, total_iterations, domains_pruned, gini_coefficient, clashes_count, success, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
      )
      .run(
        data.executionTimeMs,
        data.totalIterations,
        data.domainsPruned,
        data.giniCoefficient,
        data.clashesCount,
        data.success ? 1 : 0,
        now
      );
  }

  public getSolverMetricsHistory(limit = 10): any[] {
    return this.db
      .prepare('SELECT id, execution_time_ms, total_iterations, domains_pruned, gini_coefficient, clashes_count, success, created_at FROM solver_metrics_history ORDER BY id DESC LIMIT ?')
      .all(limit);
  }

  public getDatabaseStats(): DatabaseStats {
    const batchesCount = (this.db.prepare('SELECT COUNT(*) as c FROM batches').get() as any).c;
    const facultyCount = (this.db.prepare('SELECT COUNT(*) as c FROM faculty').get() as any).c;
    const classroomsCount = (this.db.prepare('SELECT COUNT(*) as c FROM classrooms').get() as any).c;
    const subjectsCount = (this.db.prepare('SELECT COUNT(*) as c FROM subjects').get() as any).c;
    const allocationsCount = (this.db.prepare('SELECT COUNT(*) as c FROM allocations').get() as any).c;

    let fileSizeBytes = 0;
    try {
      if (fs.existsSync(this.dbPath)) {
        fileSizeBytes = fs.statSync(this.dbPath).size;
      }
    } catch {}

    const journalMode = (this.db.prepare('PRAGMA journal_mode;').get() as any).journal_mode || 'wal';

    return {
      engine: 'SQLite 3 (Node.js native DatabaseSync)',
      journalMode: journalMode.toUpperCase(),
      path: this.dbPath,
      fileSizeBytes,
      tables: {
        batches: batchesCount,
        faculty: facultyCount,
        classrooms: classroomsCount,
        subjects: subjectsCount,
        allocations: allocationsCount,
      },
    };
  }

  public close(): void {
    this.db.close();
  }
}

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { TimetableDatabase } from '../server/db/database';
import { INITIAL_DATASET } from '../src/sampleData';
import { Batch } from '../src/types';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const TEST_DB_PATH = path.join(__dirname, 'test-classclockwork.db');

describe('SQLite Relational Database Engine (TimetableDatabase)', () => {
  let db: TimetableDatabase;

  beforeEach(() => {
    if (fs.existsSync(TEST_DB_PATH)) {
      try { fs.unlinkSync(TEST_DB_PATH); } catch {}
    }
    db = new TimetableDatabase(TEST_DB_PATH);
  });

  afterEach(() => {
    db.close();
    if (fs.existsSync(TEST_DB_PATH)) {
      try { fs.unlinkSync(TEST_DB_PATH); } catch {}
    }
  });

  it('initializes relational schema and enables WAL mode', () => {
    const stats = db.getDatabaseStats();
    expect(stats.engine).toContain('SQLite 3');
    expect(stats.journalMode).toBe('WAL');
    expect(stats.tables.batches).toBe(INITIAL_DATASET.batches.length);
    expect(stats.tables.faculty).toBe(INITIAL_DATASET.faculty.length);
    expect(stats.tables.classrooms).toBe(INITIAL_DATASET.classrooms.length);
    expect(stats.tables.subjects).toBe(INITIAL_DATASET.subjects.length);
  });

  it('retrieves typed dataset correctly matching initial benchmark scenario', () => {
    const data = db.getDataset();
    expect(data.batches).toHaveLength(INITIAL_DATASET.batches.length);
    expect(data.faculty).toHaveLength(INITIAL_DATASET.faculty.length);
    expect(data.classrooms).toHaveLength(INITIAL_DATASET.classrooms.length);
    expect(data.subjects).toHaveLength(INITIAL_DATASET.subjects.length);

    // Verify relations and nested data
    const facWithSlots = data.faculty.find((f) => f.unavailableSlots.length > 0);
    expect(facWithSlots).toBeDefined();

    const labRoom = data.classrooms.find((r) => r.type === 'LAB');
    expect(labRoom?.equipment.length).toBeGreaterThan(0);
  });

  it('performs CRUD operations on Batches with relational integrity', () => {
    const testBatch: Batch = {
      id: 'batch-test-new',
      name: 'B.Tech CS 8th Sem AI',
      code: 'CS-8-AI',
      size: 45,
      department: 'Computer Science & Engineering',
    };

    db.upsertBatch(testBatch);
    let data = db.getDataset();
    let saved = data.batches.find((b) => b.id === testBatch.id);
    expect(saved).toBeDefined();
    expect(saved?.size).toBe(45);

    // Update
    testBatch.size = 50;
    db.upsertBatch(testBatch);
    data = db.getDataset();
    saved = data.batches.find((b) => b.id === testBatch.id);
    expect(saved?.size).toBe(50);

    // Delete
    db.deleteBatch(testBatch.id);
    data = db.getDataset();
    expect(data.batches.some((b) => b.id === testBatch.id)).toBe(false);
  });

  it('records and queries solver metrics telemetry in SQLite', () => {
    db.recordSolverMetric({
      executionTimeMs: 25,
      totalIterations: 44,
      domainsPruned: 12,
      giniCoefficient: 0.12,
      clashesCount: 0,
      success: true,
    });

    const history = db.getSolverMetricsHistory(5);
    expect(history.length).toBeGreaterThanOrEqual(1);
    expect(history[0].execution_time_ms).toBe(25);
    expect(history[0].gini_coefficient).toBe(0.12);
  });
});

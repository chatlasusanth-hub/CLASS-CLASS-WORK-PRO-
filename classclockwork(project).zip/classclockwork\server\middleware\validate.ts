import { Request, Response, NextFunction } from 'express';
import { ZodSchema, ZodError } from 'zod';

export function validateBody(schema: ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      req.body = schema.parse(req.body);
      next();
    } catch (err: any) {
      if (err instanceof ZodError || err?.issues || err?.errors) {
        const issuesList = err.issues || err.errors || [];
        return res.status(400).json({
          success: false,
          error: {
            code: 'VALIDATION_ERROR',
            message: 'Invalid request payload',
            issues: issuesList.map((e: any) => ({
              path: Array.isArray(e.path) ? e.path.join('.') : String(e.path || ''),
              message: e.message,
              code: e.code,
            })),
          },
        });
      }
      next(err);
    }
  };
}

export function validateQuery(schema: ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      req.query = schema.parse(req.query) as any;
      next();
    } catch (err: any) {
      if (err instanceof ZodError || err?.issues || err?.errors) {
        const issuesList = err.issues || err.errors || [];
        return res.status(400).json({
          success: false,
          error: {
            code: 'QUERY_VALIDATION_ERROR',
            message: 'Invalid query parameters',
            issues: issuesList.map((e: any) => ({
              path: Array.isArray(e.path) ? e.path.join('.') : String(e.path || ''),
              message: e.message,
            })),
          },
        });
      }
      next(err);
    }
  };
}

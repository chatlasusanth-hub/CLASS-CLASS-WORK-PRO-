import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../utils/apiError';
import { logger } from '../utils/logger';

export function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  const reqId = req.id;

  if (err instanceof ApiError) {
    logger.warn(`API Error [${err.code}]: ${err.message}`, { details: err.details }, reqId);
    return res.status(err.statusCode).json({
      success: false,
      error: {
        code: err.code,
        message: err.message,
        details: err.details,
      },
      requestId: reqId,
    });
  }

  // Handle SyntaxError (e.g. malformed JSON in request body)
  if (err instanceof SyntaxError && 'body' in err) {
    logger.warn(`Malformed JSON in request body: ${err.message}`, undefined, reqId);
    return res.status(400).json({
      success: false,
      error: {
        code: 'MALFORMED_JSON',
        message: 'Request body contains invalid JSON syntax',
      },
      requestId: reqId,
    });
  }

  // Unhandled / server errors
  logger.error(`Unhandled Server Exception: ${err.message}`, { stack: err.stack }, reqId);

  return res.status(500).json({
    success: false,
    error: {
      code: 'INTERNAL_SERVER_ERROR',
      message: 'An unexpected error occurred while processing your request',
    },
    requestId: reqId,
  });
}

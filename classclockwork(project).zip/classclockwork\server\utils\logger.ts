export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  requestId?: string;
  meta?: Record<string, any>;
}

class Logger {
  private levelWeights: Record<LogLevel, number> = {
    DEBUG: 1,
    INFO: 2,
    WARN: 3,
    ERROR: 4,
  };

  private currentLevel: LogLevel = 'INFO';
  private buffer: LogEntry[] = [];
  private maxBufferSize = 200;

  constructor() {
    if (process.env.LOG_LEVEL) {
      const envLevel = process.env.LOG_LEVEL.toUpperCase() as LogLevel;
      if (this.levelWeights[envLevel]) {
        this.currentLevel = envLevel;
      }
    }
  }

  public setLevel(level: LogLevel): void {
    this.currentLevel = level;
  }

  private shouldLog(level: LogLevel): boolean {
    return this.levelWeights[level] >= this.levelWeights[this.currentLevel];
  }

  private log(level: LogLevel, message: string, meta?: Record<string, any>, requestId?: string): void {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      requestId,
      meta,
    };

    // Store in circular buffer for observability API
    this.buffer.push(entry);
    if (this.buffer.length > this.maxBufferSize) {
      this.buffer.shift();
    }

    if (!this.shouldLog(level)) return;

    const reqTag = requestId ? `[${requestId.slice(0, 8)}]` : '';
    const metaStr = meta ? ` ${JSON.stringify(meta)}` : '';
    const formatted = `[${entry.timestamp}] [${level}] ${reqTag} ${message}${metaStr}`;

    if (level === 'ERROR') {
      console.error(formatted);
    } else if (level === 'WARN') {
      console.warn(formatted);
    } else {
      console.log(formatted);
    }
  }

  public debug(message: string, meta?: Record<string, any>, requestId?: string): void {
    this.log('DEBUG', message, meta, requestId);
  }

  public info(message: string, meta?: Record<string, any>, requestId?: string): void {
    this.log('INFO', message, meta, requestId);
  }

  public warn(message: string, meta?: Record<string, any>, requestId?: string): void {
    this.log('WARN', message, meta, requestId);
  }

  public error(message: string, meta?: Record<string, any>, requestId?: string): void {
    this.log('ERROR', message, meta, requestId);
  }

  public getRecentLogs(limit = 50): LogEntry[] {
    return this.buffer.slice(-limit);
  }
}

export const logger = new Logger();

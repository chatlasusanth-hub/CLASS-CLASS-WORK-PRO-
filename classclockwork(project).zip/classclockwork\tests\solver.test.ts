import { describe, it, expect } from 'vitest';
import {
  TimetableCSPSolver,
  calculateGiniCoefficient,
  calculatePreferenceSatisfaction,
} from '../src/solver';
import { auditTimetable } from '../src/validator';
import { INITIAL_DATASET } from '../src/sampleData';
import { Batch, Classroom, Faculty, Subject, TimetableAllocation } from '../src/types';

describe('TimetableCSPSolver & Heuristics', () => {
  it('generates a 100% conflict-free timetable for the benchmark CS semester scenario', () => {
    const solver = new TimetableCSPSolver(
      INITIAL_DATASET.batches,
      INITIAL_DATASET.faculty,
      INITIAL_DATASET.classrooms,
      INITIAL_DATASET.subjects,
      { respectLunchBreak: true, lunchPeriod: 4, timeoutMs: 5000, useAC3: true }
    );

    const result = solver.solve();

    expect(result.success).toBe(true);
    expect(result.allocations.length).toBeGreaterThan(35);
    expect(result.unallocatedSubjects).toHaveLength(0);

    // Audit using real-time conflict detector
    const clashes = auditTimetable({
      batches: INITIAL_DATASET.batches,
      faculty: INITIAL_DATASET.faculty,
      classrooms: INITIAL_DATASET.classrooms,
      subjects: INITIAL_DATASET.subjects,
      allocations: result.allocations,
      lunchPeriod: 4,
    });

    const criticalClashes = clashes.filter((c) => c.severity === 'CRITICAL');
    expect(criticalClashes).toHaveLength(0);
  });

  it('enforces uniform protected Departmental Lunch Break (Period 4)', () => {
    const solver = new TimetableCSPSolver(
      INITIAL_DATASET.batches,
      INITIAL_DATASET.faculty,
      INITIAL_DATASET.classrooms,
      INITIAL_DATASET.subjects,
      { respectLunchBreak: true, lunchPeriod: 4, useAC3: true }
    );

    const result = solver.solve();
    expect(result.success).toBe(true);

    // Check that NO allocation starts or spans through lunch period (Period 4)
    for (const alloc of result.allocations) {
      const start = alloc.period;
      const end = alloc.period + (alloc.duration || 1) - 1;
      expect(start <= 4 && end >= 4).toBe(false);
    }
  });

  it('ensures continuous multi-period laboratory macro-slots do not bridge lunch', () => {
    const solver = new TimetableCSPSolver(
      INITIAL_DATASET.batches,
      INITIAL_DATASET.faculty,
      INITIAL_DATASET.classrooms,
      INITIAL_DATASET.subjects,
      { respectLunchBreak: true, lunchPeriod: 4, useAC3: true }
    );

    const result = solver.solve();
    const labAllocations = result.allocations.filter((a) => (a.duration || 1) >= 2);

    expect(labAllocations.length).toBeGreaterThan(0);

    for (const lab of labAllocations) {
      const start = lab.period;
      const end = lab.period + lab.duration - 1;

      // Must be completely before lunch (periods 1-3) OR completely after lunch (periods 5-7)
      const isMorning = end < 4;
      const isAfternoon = start > 4;
      expect(isMorning || isAfternoon).toBe(true);
    }
  });

  it('strictly adheres to faculty maxWeeklyHours limits', () => {
    const solver = new TimetableCSPSolver(
      INITIAL_DATASET.batches,
      INITIAL_DATASET.faculty,
      INITIAL_DATASET.classrooms,
      INITIAL_DATASET.subjects,
      { respectLunchBreak: true, lunchPeriod: 4 }
    );

    const result = solver.solve();
    const hoursMap = new Map<string, number>();

    for (const alloc of result.allocations) {
      const cur = hoursMap.get(alloc.facultyId) || 0;
      hoursMap.set(alloc.facultyId, cur + (alloc.duration || 1));
    }

    for (const fac of INITIAL_DATASET.faculty) {
      const assigned = hoursMap.get(fac.id) || 0;
      expect(assigned).toBeLessThanOrEqual(fac.maxWeeklyHours);
    }
  });

  it('respects faculty unavailable slots', () => {
    const solver = new TimetableCSPSolver(
      INITIAL_DATASET.batches,
      INITIAL_DATASET.faculty,
      INITIAL_DATASET.classrooms,
      INITIAL_DATASET.subjects,
      { respectLunchBreak: true, lunchPeriod: 4 }
    );

    const result = solver.solve();

    for (const fac of INITIAL_DATASET.faculty) {
      for (const unavail of fac.unavailableSlots) {
        const violated = result.allocations.some((a) => {
          if (a.facultyId !== fac.id || a.day !== unavail.day) return false;
          const end = a.period + (a.duration || 1) - 1;
          return unavail.period >= a.period && unavail.period <= end;
        });
        expect(violated).toBe(false);
      }
    }
  });

  it('applies AC-3 Arc Consistency preprocessing and prunes search space', () => {
    const solver = new TimetableCSPSolver(
      INITIAL_DATASET.batches,
      INITIAL_DATASET.faculty,
      INITIAL_DATASET.classrooms,
      INITIAL_DATASET.subjects,
      { respectLunchBreak: true, lunchPeriod: 4, useAC3: true }
    );

    const result = solver.solve();
    expect(result.ac3Stats).toBeDefined();
    expect(result.ac3Stats!.arcRevisions).toBeGreaterThan(0);
  });
});

describe('Mathematical Equity & Preference Metrics', () => {
  it('correctly computes the Gini coefficient', () => {
    const sampleFaculty: Faculty[] = [
      { id: 'f1', name: 'Fac 1', email: 'f1@test.edu', department: 'CS', maxWeeklyHours: 10, preferredSlot: 'ANY', unavailableSlots: [] },
      { id: 'f2', name: 'Fac 2', email: 'f2@test.edu', department: 'CS', maxWeeklyHours: 10, preferredSlot: 'ANY', unavailableSlots: [] },
    ];

    // Perfect equality: both teach 4 hours
    const equalAllocations: TimetableAllocation[] = [
      { id: 'a1', subjectId: 's1', batchId: 'b1', facultyId: 'f1', roomId: 'r1', day: 'Monday', period: 1, duration: 4 },
      { id: 'a2', subjectId: 's2', batchId: 'b2', facultyId: 'f2', roomId: 'r2', day: 'Monday', period: 1, duration: 4 },
    ];

    const giniEqual = calculateGiniCoefficient(sampleFaculty, equalAllocations);
    expect(giniEqual).toBe(0);

    // Extreme inequality: f1 teaches 8 hours, f2 teaches 0 hours
    const unequalAllocations: TimetableAllocation[] = [
      { id: 'a1', subjectId: 's1', batchId: 'b1', facultyId: 'f1', roomId: 'r1', day: 'Monday', period: 1, duration: 8 },
    ];

    const giniUnequal = calculateGiniCoefficient(sampleFaculty, unequalAllocations);
    expect(giniUnequal).toBeGreaterThan(0.4);
  });

  it('computes soft preference satisfaction percentage correctly', () => {
    const faculty: Faculty[] = [
      { id: 'f1', name: 'Morning Prof', email: 'm@test.edu', department: 'CS', maxWeeklyHours: 10, preferredSlot: 'MORNING', unavailableSlots: [] },
      { id: 'f2', name: 'Afternoon Prof', email: 'a@test.edu', department: 'CS', maxWeeklyHours: 10, preferredSlot: 'AFTERNOON', unavailableSlots: [] },
    ];

    // Slot 1 (09:00) is morning (<= 3), Slot 5 (13:00) is afternoon (> 3)
    const matchingAllocations: TimetableAllocation[] = [
      { id: 'a1', subjectId: 's1', batchId: 'b1', facultyId: 'f1', roomId: 'r1', day: 'Monday', period: 1, duration: 1 },
      { id: 'a2', subjectId: 's2', batchId: 'b2', facultyId: 'f2', roomId: 'r2', day: 'Monday', period: 5, duration: 1 },
    ];

    const satisfaction = calculatePreferenceSatisfaction(faculty, matchingAllocations);
    expect(satisfaction).toBe(100);
  });
});
